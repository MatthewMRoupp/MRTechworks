# Attribution policy for MR Techworks editorial articles

- Cite non-trivial news claims, technical specifications, statistics, release dates, and security advisories to the original publisher or reputable reporting; place direct links with descriptive labels in a Sources section.
- Prefer original prose that explains relevance to readers. Direct quotations must be exact, short, in quotation marks/blockquote, and attributed to the named speaker or author and source publication with link.
- Credit is **not** permission to duplicate a copyrighted article, photograph, screenshot or illustration. Check actual reuse rights, which may differ between text and images on the same page.
- Use free stock under its site-specific terms, freely licensed Creative Commons images with correct license-specific attribution, original photographs, or permitted publisher press imagery with documented conditions. Never assume an editorial/press image is free to republish.
- Display image credits immediately below the picture or in a clearly linked credits section, naming creator, original source URL, license URL and edits for CC BY / CC BY-SA. For CC BY-SA derivatives, honor share-alike requirements.
- Make illustration status clear. A generic game-controller photo is not a GTA VI screenshot; an inbox photo is not proof of a Microsoft outage.
- Keep the media-source URL, author, license and file path in a persistent manifest. If permission is unclear, skip the image and retain a local generic placeholder.
- For search accessibility use a precise alt attribute and descriptive page metadata; do not keyword-stuff alt text.
