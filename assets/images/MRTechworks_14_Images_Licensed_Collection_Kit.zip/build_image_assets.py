#!/usr/bin/env python3
"""Download rights-screened article photo candidates and build an optimized WebP ZIP.

Run locally with internet access after reading image licensing and source page terms:
    py -m pip install Pillow
    py build_image_assets.py

Source images are downloaded unchanged first, then resized/cropped to 1200x675
for site thumbnails. The script writes an accompanying credits file. For CC BY
and CC BY-SA photos, captions must remain visible on the article pages.
"""
from __future__ import annotations
import csv
import io
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

try:
    from PIL import Image, ImageOps, UnidentifiedImageError
except ImportError:
    print("Pillow is required: py -m pip install Pillow")
    sys.exit(2)

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets" / "images"
RAW = ROOT / "originals_downloaded"
OUTZIP = ROOT / "MRTechworks_14_Optimized_Images.zip"
TARGET_SIZE = (1200, 675)
ASSETS.mkdir(parents=True, exist_ok=True)
RAW.mkdir(parents=True, exist_ok=True)

with (ROOT / "article_image_sources.csv").open("r", encoding="utf-8-sig", newline="") as fh:
    ROWS = list(csv.DictReader(fh))


def candidate_urls(row: dict) -> list[str]:
    page = row["source_url"]
    if "pexels.com/photo/" in page:
        m = re.search(r"-(\d+)/?$", page)
        if not m:
            raise ValueError(f"Missing Pexels photo id in {page}")
        photo_id = m.group(1)
        base = f"https://images.pexels.com/photos/{photo_id}/pexels-photo-{photo_id}.jpeg"
        return [base + "?auto=compress&cs=tinysrgb&w=1600", base]
    if "commons.wikimedia.org/wiki/File:" in page:
        filename = urllib.parse.unquote(page.split("File:", 1)[1])
        return ["https://commons.wikimedia.org/wiki/Special:Redirect/file/" + urllib.parse.quote(filename, safe="")]
    return []


def download_candidate(row: dict):
    filename = Path(row["filename"]).stem
    # Manual fallback: if the source's download endpoint is blocked, save its
    # image in originals_downloaded/ with the same stem as the target filename.
    for ext in (".jpg", ".jpeg", ".png", ".webp"):
        candidate = RAW / (filename + ext)
        if candidate.is_file():
            try:
                raw = candidate.read_bytes()
                with Image.open(io.BytesIO(raw)) as check:
                    check.verify()
                return io.BytesIO(raw), "manually downloaded from " + row["source_url"]
            except Exception as exc:
                print("  Ignoring invalid local input:", candidate.name, exc)
    if "--local-only" in sys.argv:
        return None, None
    for n, url in enumerate(candidate_urls(row)):
        try:
            request = urllib.request.Request(url, headers={
                "User-Agent": "MRTechworks-ImagePack/1.0 (licensed editorial asset collection)",
                "Accept": "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8",
            })
            with urllib.request.urlopen(request, timeout=35) as response:
                image_bytes = response.read(30 * 1024 * 1024 + 1)
                if len(image_bytes) > 30 * 1024 * 1024:
                    raise ValueError("Source exceeds 30MB download cap")
                content_type = response.headers.get("Content-Type", "")
                if "image" not in content_type and not image_bytes.startswith((b"\xff\xd8", b"\x89PNG", b"RIFF")):
                    raise ValueError(f"Unexpected response type: {content_type}")
            im = Image.open(io.BytesIO(image_bytes))
            im.verify()
            # Preserve each downloaded original for license and version records.
            ext = ".png" if image_bytes.startswith(b"\x89PNG") else ".jpg"
            (RAW / f"{filename}{ext}").write_bytes(image_bytes)
            return io.BytesIO(image_bytes), url
        except (urllib.error.URLError, ValueError, UnidentifiedImageError, TimeoutError, OSError) as exc:
            print(f"  Candidate {n+1} failed: {type(exc).__name__}: {exc}")
            time.sleep(0.25)
    return None, None


credits = []
failed = []
for i, row in enumerate(ROWS, 1):
    print(f"[{i}/{len(ROWS)}] {row['filename']} — {row['creator']}")
    stream, download_url = download_candidate(row)
    if stream is None:
        failed.append(row)
        print("  Failed. Visit:", row["source_url"])
        continue
    try:
        with Image.open(stream) as im:
            rgb = ImageOps.exif_transpose(im).convert("RGB")
            # Center crop deliberately; visible credit states image was resized/cropped.
            optimized = ImageOps.fit(rgb, TARGET_SIZE, method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
            dest = ASSETS / row["filename"]
            optimized.save(dest, "WEBP", quality=82, method=6)
        print(f"  Saved {dest.name} ({dest.stat().st_size // 1024} KB)")
        credits.append({
            "article_url": row["article_url"],
            "asset": "/assets/images/" + row["filename"],
            "alt": row["alt"],
            "creator": row["creator"],
            "source_url": row["source_url"],
            "license": row["license"],
            "license_url": row["license_url"],
            "credit_required": row["credit_required"],
            "modifications": "Resized and center-cropped to 1200x675; converted to WebP",
            "caption": row["caption"],
            "download_url": download_url,
        })
    except Exception as exc:
        failed.append(row)
        print("  Conversion failed:", exc)

credits_path = ROOT / "credits_for_uploaded_images.json"
credits_path.write_text(json.dumps(credits, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
with zipfile.ZipFile(OUTZIP, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for row in credits:
        local = ASSETS / Path(row["asset"]).name
        zf.write(local, arcname="assets/images/" + local.name)
    zf.write(credits_path, arcname="credits_for_uploaded_images.json")
    zf.write(ROOT / "article_image_sources.csv", arcname="article_image_sources.csv")
print(f"\nFinished: {len(credits)} images; {len(failed)} failed; ZIP: {OUTZIP}")
if failed:
    print("\nMANUAL DOWNLOADS REQUIRED:")
    for row in failed:
        print(" -", row["filename"], row["source_url"])
    sys.exit(1)
