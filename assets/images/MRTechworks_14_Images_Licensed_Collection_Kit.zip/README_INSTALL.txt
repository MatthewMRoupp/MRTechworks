# MR Techworks — Licensed image collection kit (14 article images)

This ZIP contains **source information, a downloader/optimizer script, and reusable credits**, not the actual copyrighted or licensed image binaries. Source pages and licenses were checked, but direct downloads were unavailable in the working environment. Do not upload the placeholder file or claim images are already installed.

## Quick start on Windows

1. Extract this ZIP to a folder.
2. Install Python 3 if needed. Open Terminal in that folder.
3. Install Pillow: `py -m pip install Pillow`
4. Run: `py build_image_assets.py`
5. The script downloads permitted source images and creates **MRTechworks_14_Optimized_Images.zip** containing optimized `/assets/images/*.webp` plus the credits manifest.
6. If individual downloads fail, visit the source URLs in `browse_image_sources.html` or `article_image_sources.csv`. Save the downloaded original in `originals_downloaded/` using the same filename **stem** (e.g., `steam-machine-2026.jpg`, `switch-2-compatibility.png`), then rerun the script. To process saved images without network calls: `py build_image_assets.py --local-only`.
7. Check the resulting images visually. Do not upload unexpectedly different, watermarked, or license-changed images. Verify each source license has not changed.
8. Upload the optimized `.webp` files to **/assets/images/** in `MatthewMRoupp/MRTechworks`. Provide the updated ZIP or upload them through GitHub; the website's page and index references must then be updated to use the new filenames.
9. Add visible credits in each article where required (CC BY and CC BY-SA), including **creator + linked original + linked license + notice that resized/cropped/converted**. Courtesy credits are recommended for Pexels and CC0 too. See `ARTICLE_IMAGE_CREDIT_SNIPPETS.html`.

## Permissions and guardrails

- **Pexels License**: website/commercial use permitted, attribution not required but appreciated; do not imply a brand or person endorsed MR Techworks. https://www.pexels.com/license/
- **CC BY 4.0**: author/source/license credit and modification notice required. https://creativecommons.org/licenses/by/4.0/
- **CC BY-SA 4.0**: same credit requirements, and adapted versions must be under the same or compatible share-alike license. https://creativecommons.org/licenses/by-sa/4.0/
- **CC0**: public-domain dedication; courtesy credit desirable. https://creativecommons.org/publicdomain/zero/1.0/
- **Third-party newsroom photographs, press releases, screenshots or article images** are not automatically licensed for reuse just because a link or credit is shown. Use them only after finding a clear license/press-use grant or receiving explicit permission. Otherwise use a separate freely licensed photo or illustration with clear labels.
- **Facts** can be written in original words with a citation; **direct quotations** use quotation marks and identify the speaker, publisher, article and source link. Don't republish entire articles or extensive passages solely by adding attribution.

## Metadata and SEO

After installation, update `/assets/js/library-data.js` with the filename and alt text, update each article's hero `<img>` and `og:image`, and link the image license and creator on that article. Include `ImageObject` credit metadata when practical, but visible credits remain important. Never publish broken image URLs ahead of uploads.

The script creates WebP images at 1200 × 675, quality 82, for manageable site sizes. Cropping/format conversion counts as modification for credit purposes. A 16:9 image should not be misrepresented as real gameplay or an actual outage screen if it's generic stock photography.
